package sample.demo.atos.demo.view;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

import sample.demo.atos.demo.R;
import sample.demo.atos.demo.adapter.HContactAdapter;
import sample.demo.atos.demo.listener.HContactCallback;
import sample.demo.atos.demo.model.HCModel;
import sample.demo.atos.demo.taskmanager.HContactTask;

public class EmployeeListActivity extends AppCompatActivity implements HContactCallback {

    // employee list
    private ListView mEmployeeList;
    // employee adapter
    private HContactAdapter mHContactAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_list);

        initView();
        new HContactTask(this).execute();
    }

    private void initView() {
        mEmployeeList = (ListView) findViewById(R.id.employee_list);
    }

    @Override
    public void onCreateContactList(ArrayList<HCModel> hContactList) {
        /**
         * Updating parsed JSON data into ListView
         */
        mHContactAdapter = new HContactAdapter(EmployeeListActivity.this, hContactList);
        mEmployeeList.setAdapter(mHContactAdapter);
    }
}
