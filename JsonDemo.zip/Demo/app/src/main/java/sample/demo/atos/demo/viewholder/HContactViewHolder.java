package sample.demo.atos.demo.viewholder;

import android.widget.TextView;

/**
 * Created by A643637 on 05-10-2016.
 */

public class HContactViewHolder {

    public TextView mName;
    public TextView mAge;
    public TextView mAddress;
    public TextView mContact;
}
