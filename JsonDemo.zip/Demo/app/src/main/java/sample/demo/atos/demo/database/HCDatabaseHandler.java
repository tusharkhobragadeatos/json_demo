package sample.demo.atos.demo.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

import sample.demo.atos.demo.HCApplication;
import sample.demo.atos.demo.model.HCAddressModel;
import sample.demo.atos.demo.model.HCModel;
import sample.demo.atos.demo.model.HCPhoneNumberModel;

/**
 * Created by A643637 on 05-10-2016.
 */

public class HCDatabaseHandler extends SQLiteOpenHelper {

    private static HCDatabaseHandler mInstance = null;

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "HollywoodContacts";
    // table for hollywood contacts
    private static final String TABLE_HCONTACTS = "HContacts";
    // table for HC address
    private static final String TABLE_HCONTACTS_ADDRESS = "HContactsAddress";
    // table for HC phone number
    private static final String TABLE_HCONTACTS_PHONE_NUMBER = "HContactsPhoneNumber";

    // HC data
    private static final String KEY_ID = "id";
    private static final String KEY_CONTACT_ID = "contactId";
    private static final String KEY_FIRST_NAME = "firstName";
    private static final String KEY_LAST_NAME = "lastName";
    private static final String KEY_AGE = "age";

    // HC  address
    private static final String KEY_STREET_ADDRESS = "streetAddress";
    private static final String KEY_CITY = "city";
    private static final String KEY_STATE = "state";
    private static final String KEY_POSTAL_CODE = "postalCode";

    // HC  phone number
    private static final String KEY_TYPE = "type";
    private static final String KEY_NUMBER = "number";

    public static HCDatabaseHandler getInstance(Context context) {
        /**
         * use the application context as suggested by CommonsWare.
         * this will ensure that you dont accidentally leak an Activitys
         * context (see this article for more information:
         * http://android-developers.blogspot.nl/2009/01/avoiding-memory-leaks.html)
         */
        if (mInstance == null) {
            mInstance = new HCDatabaseHandler(context);
        }
        return mInstance;
    }

    public HCDatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //3rd argument to be passed is CursorFactory instance
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_HCONTACTS_TABLE = "CREATE TABLE " + TABLE_HCONTACTS + "("
                + KEY_CONTACT_ID + " INTEGER  PRIMARY KEY," + KEY_FIRST_NAME + " TEXT,"
                + KEY_LAST_NAME + " TEXT," + KEY_AGE + " TEXT" + ")";

        String CREATE_HCONTACTS_ADDRESS_TABLE = "CREATE TABLE " + TABLE_HCONTACTS_ADDRESS + "("
                + KEY_CONTACT_ID + " INTEGER," + KEY_STREET_ADDRESS + " TEXT,"
                + KEY_CITY + " TEXT," + KEY_STATE + " TEXT,"
                + KEY_POSTAL_CODE + " TEXT" + ")";

        String CREATE_HCONTACTS_PHONE_NUMBER_TABLE = "CREATE TABLE " + TABLE_HCONTACTS_PHONE_NUMBER + "("
                + KEY_CONTACT_ID + " INTEGER," + KEY_TYPE + " TEXT,"
                + KEY_NUMBER + " TEXT" + ")";

        db.execSQL(CREATE_HCONTACTS_TABLE);
        db.execSQL(CREATE_HCONTACTS_ADDRESS_TABLE);
        db.execSQL(CREATE_HCONTACTS_PHONE_NUMBER_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HCONTACTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HCONTACTS_ADDRESS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HCONTACTS_PHONE_NUMBER);

        // Create tables again
        onCreate(db);
    }

    // code to add the new contact
    public void addHContacts(HCModel hContact) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_CONTACT_ID, hContact.getContactId());
        values.put(KEY_FIRST_NAME, hContact.getFirstName());
        values.put(KEY_LAST_NAME, hContact.getLastName());
        values.put(KEY_AGE, hContact.getAge());

        // Inserting Row
        db.insert(TABLE_HCONTACTS, null, values);
        //2nd argument is String containing nullColumnHack
        //db.close(); // Closing database connection
        //addHContactsAddress(hContact);
    }

    // code to add the new contact
    public void addHContactsAddress(HCModel hcModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        HCAddressModel hcAddressModel = hcModel.getHcAddressModel();
        ContentValues values = new ContentValues();
        values.put(KEY_CONTACT_ID, hcModel.getContactId());
        values.put(KEY_STREET_ADDRESS, hcAddressModel.getStreetAddress());
        values.put(KEY_CITY, hcAddressModel.getCity());
        values.put(KEY_STATE, hcAddressModel.getState());
        values.put(KEY_POSTAL_CODE, hcAddressModel.getPostalCode());

        // Inserting Row
        db.insert(TABLE_HCONTACTS_ADDRESS, null, values);
        //2nd argument is String containing nullColumnHack
        //db.close(); // Closing database connection
        //addHContactsPhoneNumber(hcModel);
    }

    // code to add the new contact
    public void addHContactsPhoneNumber(HCModel hContact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<HCPhoneNumberModel> hcPhoneNumberModels = hContact.getHcPhoneNumberModel();
        for (HCPhoneNumberModel hcPhoneNumberModel : hcPhoneNumberModels) {
            ContentValues values = new ContentValues();
            values.put(KEY_CONTACT_ID, hContact.getContactId());
            values.put(KEY_TYPE, hcPhoneNumberModel.getType());
            values.put(KEY_NUMBER, hcPhoneNumberModel.getNumber());

            // Inserting Row
            db.insert(TABLE_HCONTACTS_PHONE_NUMBER, null, values);
            //2nd argument is String containing nullColumnHack
            //db.close(); // Closing database connection
        }
    }

    // code to get all Contacts in a list view
    public ArrayList<HCModel> getAllHContacts() {
        ArrayList<HCModel> hContacts = new ArrayList<>();
        // Select All Query
        String selectHContactQuery = "SELECT  * FROM " + TABLE_HCONTACTS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectHContactQuery, null);

        if (cursor.moveToFirst()) {
            do {
                HCModel hcontact = new HCModel();
                hcontact.setContactId(cursor.getLong(0));
                hcontact.setFirstName(cursor.getString(1));
                hcontact.setLastName(cursor.getString(2));
                hcontact.setAge(cursor.getInt(3));
                // Adding employee to list
                hContacts.add(hcontact);
            } while (cursor.moveToNext());
        }

        // return contact list
        return hContacts;
    }

    // code to get contact address in a list view
    public HCAddressModel getHContactsAddress(long contactId) {
        HCAddressModel hcAddressModel = null;
        SQLiteDatabase db = this.getWritableDatabase();
        String selectContactAddresQuery = "SELECT  * FROM " + TABLE_HCONTACTS_ADDRESS + " WHERE "
                + KEY_CONTACT_ID + " = " + contactId;
        Cursor addressCursor = db.rawQuery(selectContactAddresQuery, null);
        if (addressCursor.moveToFirst()) {
            do {
                hcAddressModel = new HCAddressModel();
                hcAddressModel.setStreetAddress(addressCursor.getString(1));
                hcAddressModel.setCity(addressCursor.getString(2));
                hcAddressModel.setState(addressCursor.getString(3));
                hcAddressModel.setPostalCode(addressCursor.getLong(4));
            } while (addressCursor.moveToNext());
        }
        return hcAddressModel;
    }

    // code to get contact address in a list view
    public ArrayList<HCPhoneNumberModel> getHContactsPhoneNumber(long contactId) {
        ArrayList<HCPhoneNumberModel> hcPhoneNumberModels = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        String selectContactAddresQuery = "SELECT  * FROM " + TABLE_HCONTACTS_PHONE_NUMBER + " WHERE "
                + KEY_CONTACT_ID + " = " + contactId;
        Cursor phoneCursor = db.rawQuery(selectContactAddresQuery, null);
        if (phoneCursor.moveToFirst()) {
            do {
                HCPhoneNumberModel hcPhoneNumberModel = new HCPhoneNumberModel();
                hcPhoneNumberModel.setType(phoneCursor.getString(1));
                hcPhoneNumberModel.setNumber(phoneCursor.getString(2));
                hcPhoneNumberModels.add(hcPhoneNumberModel);
            } while (phoneCursor.moveToNext());
        }
        return hcPhoneNumberModels;
    }

    // Getting hcontatcs Count
    public int getContactsCount() {
        int count;
        String countQuery = "SELECT  * FROM " + TABLE_HCONTACTS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        count = cursor.getCount();
        cursor.close();

        // return count
        return count;
    }
}
