package sample.demo.atos.demo.listener;

import java.util.ArrayList;

import sample.demo.atos.demo.model.HCModel;

/**
 * Created by A643637 on 01-11-2016.
 */

public interface HContactCallback {

    public void onCreateContactList(ArrayList<HCModel> hContactList);
}
