package sample.demo.atos.demo.assetmanager;

import android.content.Context;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by A643637 on 24-10-2016.
 */

public class HCAssetManager {

    private Context mContext;

    public HCAssetManager(Context context){
        mContext = context;
    }
    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = mContext.getAssets().open("hollywood_contact.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
