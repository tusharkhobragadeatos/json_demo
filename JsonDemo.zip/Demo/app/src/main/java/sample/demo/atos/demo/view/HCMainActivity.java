package sample.demo.atos.demo.view;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

import sample.demo.atos.demo.HCApplication;
import sample.demo.atos.demo.R;
import sample.demo.atos.demo.assetmanager.HCAssetManager;
import sample.demo.atos.demo.database.HCDatabaseHandler;
import sample.demo.atos.demo.model.HCModel;
import sample.demo.atos.demo.parser.JsonParser;
import sample.demo.atos.demo.utility.HCUtil;

public class HCMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hc_activity_main);

        initView();
        HCUtil hcUtil = new HCUtil();
        hcUtil.getActivityContext(this);
        hcUtil.readJsonData();
    }

    private void initView() {
        Button mGetContactList = (Button)findViewById(R.id.btn_get_contact_list);
        mGetContactList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HCMainActivity.this, EmployeeListActivity.class));
            }
        });
    }
}
