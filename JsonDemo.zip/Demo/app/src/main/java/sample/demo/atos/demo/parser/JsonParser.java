package sample.demo.atos.demo.parser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import sample.demo.atos.demo.model.HCAddressModel;
import sample.demo.atos.demo.model.HCModel;
import sample.demo.atos.demo.model.HCPhoneNumberModel;

/**
 * Created by A643637 on 24-10-2016.
 */

public class JsonParser {

    public ArrayList<HCModel> getHCdata(String jsonString) {
        ArrayList<HCModel> hcList = new ArrayList<>();
        try {
            JSONObject obj = new JSONObject(jsonString);
            JSONArray hContactArray = obj.getJSONArray("contacts");

            for (int i = 0 ; i < hContactArray.length(); i++){
                HCModel hContact = new HCModel();

                // adding json object
                JSONObject jo_inside = hContactArray.getJSONObject(i);
                hContact.setContactId(jo_inside.getLong("contactId"));
                hContact.setFirstName(jo_inside.getString("firstName"));
                hContact.setLastName(jo_inside.getString("lastName"));
                hContact.setAge(jo_inside.getInt("age"));

                // adding address json object
                JSONObject addressJson = jo_inside.getJSONObject("address");
                HCAddressModel hcAddress = new HCAddressModel();
                hcAddress.setStreetAddress(addressJson.getString("streetAddress"));
                hcAddress.setCity(addressJson.getString("city"));
                hcAddress.setState(addressJson.getString("state"));
                hcAddress.setPostalCode(addressJson.getLong("postalCode"));
                hContact.setHcAddressModel(hcAddress);

                // adding phone number list array object
                JSONArray phoneNumberJsonArray = jo_inside.getJSONArray("phoneNumber");
                ArrayList<HCPhoneNumberModel> hcPhoneNumberList = new ArrayList<>();
                for (int j = 0 ; j < phoneNumberJsonArray.length(); j++){
                    HCPhoneNumberModel hCPhoneNumber = new HCPhoneNumberModel();

                    JSONObject jo_phoneNumber = phoneNumberJsonArray.getJSONObject(j);
                    hCPhoneNumber.setType(jo_phoneNumber.getString("type"));
                    hCPhoneNumber.setNumber(jo_phoneNumber.getString("number"));
                    hcPhoneNumberList.add(hCPhoneNumber);
                }
                hContact.setHcPhoneNumberModel(hcPhoneNumberList);

                // adding all data in HC model list
                hcList.add(hContact);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return hcList;
    }
}
