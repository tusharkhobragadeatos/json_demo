package sample.demo.atos.demo;

import android.app.Application;

import sample.demo.atos.demo.database.HCDatabaseHandler;

/**
 * Created by A643637 on 26-10-2016.
 */

public class HCApplication extends Application {

    // application instance
    private static HCApplication mInstance;

    // database instance
    private static HCDatabaseHandler mHcDatabaseHandler;

    // get instance of application class
    public static HCApplication getInstance(){
        if (mInstance == null) {
            mInstance = new HCApplication();
        }
        return mInstance;
    }

    // get db instance for other operations
    public HCDatabaseHandler getHCDatabaseInstance(){
        return mHcDatabaseHandler;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        // get database instance
        mHcDatabaseHandler = HCDatabaseHandler.getInstance(this);
    }
}
