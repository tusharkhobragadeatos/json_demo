package sample.demo.atos.demo.model;

/**
 * Created by A643637 on 05-10-2016.
 */

public class Employee {

    // Employee ID
    private int mId;
    // Employee Name
    private String mName;
    // Employee phone no.
    private String mPhoneNumber;

    public Employee(){}

    public Employee(int id, String name, String mPhoneNumber){
        this.mId = id;
        this.mName = name;
        this.mPhoneNumber = mPhoneNumber;
    }

    public Employee(String name, String mPhoneNumber){
        this.mName = name;
        this.mPhoneNumber = mPhoneNumber;
    }
    public int getID(){
        return this.mId;
    }

    public void setID(int id){
        this.mId = id;
    }

    public String getName(){
        return this.mName;
    }

    public void setName(String name){
        this.mName = name;
    }

    public String getPhoneNumber(){
        return this.mPhoneNumber;
    }

    public void setPhoneNumber(String phone_number){
        this.mPhoneNumber = phone_number;
    }
}
