package sample.demo.atos.demo.utility;

import android.app.ProgressDialog;
import android.content.Context;

import java.util.ArrayList;

import sample.demo.atos.demo.HCApplication;
import sample.demo.atos.demo.assetmanager.HCAssetManager;
import sample.demo.atos.demo.database.HCDatabaseHandler;
import sample.demo.atos.demo.model.HCModel;
import sample.demo.atos.demo.parser.JsonParser;

/**
 * Created by A643637 on 26-10-2016.
 */

public class HCUtil {

    // progress dialog instance
    private ProgressDialog mProgressDialog;

    // class  instance
    private Context mContext;

    // get activity context
    public void getActivityContext(Context context){
        mContext = context;
    }

    public void readJsonData() {
        /*read json data at first only once come in application
        * and insert in db*/
        HCApplication hcApplication = HCApplication.getInstance();
        showProgressDialog("Inserting data into database...");
        HCDatabaseHandler hcDatabaseHandler = hcApplication.getHCDatabaseInstance();
        try {
            // calling asset manager to load json from asset
            HCAssetManager hcAssetManager = new HCAssetManager(mContext);
            String jsonString = hcAssetManager.loadJSONFromAsset();
            // parsing json data into Contact model
            JsonParser jsonParser = new JsonParser();
            ArrayList<HCModel> hContacts = jsonParser.getHCdata(jsonString);
            // inserting data into db
            if(hcDatabaseHandler.getContactsCount() == 0) {
                for (HCModel hContact : hContacts) {
                    hcDatabaseHandler.addHContacts(hContact);
                    hcDatabaseHandler.addHContactsAddress(hContact);
                    hcDatabaseHandler.addHContactsPhoneNumber(hContact);
                }
            }
            hcDatabaseHandler.close();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (hcDatabaseHandler != null){
                hcDatabaseHandler.close();
                hideProgressDialog();
            }
        }
    }

    // showing progress dialog
    private void showProgressDialog(String message){
        mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setMessage(message);
        mProgressDialog.show();
    }

    //  hide progress dialog
    private void hideProgressDialog(){
        mProgressDialog.dismiss();
        mProgressDialog.cancel();
    }

}
