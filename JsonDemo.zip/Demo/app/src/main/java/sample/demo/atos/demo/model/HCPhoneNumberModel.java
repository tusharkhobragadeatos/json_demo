package sample.demo.atos.demo.model;

/**
 * Created by A643637 on 24-10-2016.
 */

public class HCPhoneNumberModel {

    private String type;
    private String number;


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
