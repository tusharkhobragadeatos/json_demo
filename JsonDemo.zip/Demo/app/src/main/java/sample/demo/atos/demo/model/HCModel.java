package sample.demo.atos.demo.model;

import java.util.ArrayList;

/**
 * Created by A643637 on 24-10-2016.
 */

public class HCModel {
    private long ContactId;
    private String firstName;
    private String lastName;
    private int age;
    private HCAddressModel hcAddressModel;
    private ArrayList<HCPhoneNumberModel> hcPhoneNumberModel;


    public long getContactId() {
        return ContactId;
    }

    public void setContactId(long contactId) {
        ContactId = contactId;
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public HCAddressModel getHcAddressModel() {
        return hcAddressModel;
    }

    public void setHcAddressModel(HCAddressModel hcAddressModel) {
        this.hcAddressModel = hcAddressModel;
    }

    public ArrayList<HCPhoneNumberModel> getHcPhoneNumberModel() {
        return hcPhoneNumberModel;
    }

    public void setHcPhoneNumberModel(ArrayList<HCPhoneNumberModel> hcPhoneNumberModel) {
        this.hcPhoneNumberModel = hcPhoneNumberModel;
    }
}
