package sample.demo.atos.demo;

import android.content.Context;

/**
 * Created by A643637 on 27-10-2016.
 */

public class HomeScreen {

    /* employee name */
    private String mEmployeeName;
    /* employee number */
    private String mNumber;

    private Context mContext;

    /**
     * get data in json format
     * @param name name of employee
     * @param age age of employee
     * @return result result of json
     */
    private String getJsonData(String name, int age){
        String result = "";
        return result;
    }

    public HomeScreen(Context context){
        mContext = context;
    }

}

