package sample.demo.atos.demo.taskmanager;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import java.util.ArrayList;

import sample.demo.atos.demo.HCApplication;
import sample.demo.atos.demo.database.HCDatabaseHandler;
import sample.demo.atos.demo.listener.HContactCallback;
import sample.demo.atos.demo.model.HCAddressModel;
import sample.demo.atos.demo.model.HCModel;
import sample.demo.atos.demo.model.HCPhoneNumberModel;

/**
 * Created by A643637 on 01-11-2016.
 *
 * Async task class to get hollywood contacts
 */
public class HContactTask extends AsyncTask<Void, Void, ArrayList<HCModel>> {

    private Context mContext;
    /* HContactCallback instance */
    private HContactCallback mHContactCallback;

    public HContactTask(Context context){
        mContext = context;
        mHContactCallback = (HContactCallback) mContext;
    }

    ProgressDialog pDialog;

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        // Showing progress dialog
        pDialog = new ProgressDialog(mContext);
        pDialog.setMessage("getting contacts from db...");
        pDialog.setCancelable(false);
        pDialog.show();

    }

    @Override
    protected ArrayList<HCModel> doInBackground(Void... arg0) {

        ArrayList<HCModel> hContactList = new ArrayList<>();
        try {
            HCDatabaseHandler hcDatabaseHandler = HCApplication.getInstance().getHCDatabaseInstance();
            ArrayList<HCModel> hContacts = hcDatabaseHandler.getAllHContacts();
            for (HCModel hContact : hContacts){
                HCAddressModel hcAddressModel =
                        hcDatabaseHandler.getHContactsAddress(hContact.getContactId());
                hContact.setHcAddressModel(hcAddressModel);
                ArrayList<HCPhoneNumberModel> hcPhoneNumberModel =
                        hcDatabaseHandler.getHContactsPhoneNumber(hContact.getContactId());
                hContact.setHcPhoneNumberModel(hcPhoneNumberModel);
                hContactList.add(hContact);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hContactList;
    }

    @Override
    protected void onPostExecute(ArrayList<HCModel> result) {
        super.onPostExecute(result);
        // Dismiss the progress dialog
        pDialog.dismiss();
        pDialog.cancel();
        // create new contact list
        mHContactCallback.onCreateContactList(result);
    }

}
