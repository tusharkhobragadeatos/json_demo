package sample.demo.atos.demo.utility;

/**
 * Created by A643637 on 27-10-2016.
 */

public class HCContactsConstants {

    public static final String HC_FIRST_NAME = "firstName";
}
