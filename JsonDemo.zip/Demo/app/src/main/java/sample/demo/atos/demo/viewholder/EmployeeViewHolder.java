package sample.demo.atos.demo.viewholder;

import android.widget.TextView;

/**
 * Created by A643637 on 05-10-2016.
 */

public class EmployeeViewHolder {

    // Employee name
    public TextView mName;
    // Employee no.
    public TextView mPhoneNumber;
}
